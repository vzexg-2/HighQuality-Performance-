echo "Removing installation..."

(
settings delete global heads_up_notifications_disabled_package_list
device_config delete game_overlay
)> /dev/null 2>&1

function removeTouchSettings() {
    settings delete global touch.presure.scale
    settings delete system touch.size.isSummed
    settings put secure multi_press_timeout 300
    settings put secure long_press_timeout 300
    settings delete system view.touch_slop
}
echo ""
removeTouchSettings > /dev/null 2>&1

for device_config in $(cmd device_config list | cut -f 1 -d =); do
namespace=${device_config%/*}
key=${device_config#*/}
cmd device_config delete $namespace $key
done
settings put system pointer_speed 1
settings delete global pointer_speed
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete system max_refresh_rate
settings delete global touch.pressure.scale
settings delete global view.scroll_friction
settings delete global touch.size.calibration
settings delete global touch.pressure.calibration
settings delete global touch.size.scale
settings delete global touch.size.bias
settings delete global touch.size.isSummed
settings delete global touch.orientation.calibration
settings delete global touch.distance.calibration
settings delete global touch.distance.scale
settings delete global touch.coverage.calibration
settings delete global touch.gestureMode
settings delete global MultitouchMinDistancen
settings delete global MultitouchSettleInterval
settings delete global TapInterval
settings delete global TapSlop
settings delete global windowsmgr.max_events_per_sec
cmd package compile -m verify -a

mv /data/local/tmp/vulkan /sdcard/HQP/Core/
svc power reboot