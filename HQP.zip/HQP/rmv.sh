echo "Removing installation..."

(
settings delete global heads_up_notifications_disabled_package_list
device_config delete game_overlay
)> /dev/null 2>&1

function removeTouchSettings() {
    settings delete global touch.presure.scale
    settings delete system touch.size.isSummed
    settings put secure multi_press_timeout 300
    settings put secure long_press_timeout 300
    settings delete system view.touch_slop
}
echo ""
removeTouchSettings > /dev/null 2>&1
mv /data/local/tmp/vulkan /sdcard/HQP/Core/
svc power reboot