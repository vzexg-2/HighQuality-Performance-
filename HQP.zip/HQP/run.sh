#!/system/bin/sh
MODPATH=/sdcard/HQP
ver=1.4QP
dev=sunshine
rtyperenderer=Vulkan

clear
# LOG ( Info )
echo "
1.4QP
What's new about this version?
1. Added a function that can boost your network [WiFi/Mobile Data]
2. Added killer cache
3. More focused optimization on system device
4. Better than 1.3@5QP Tester, fact

Risk?

1. Your phone will drain battery fast
2. Overheat, better to use cooler
3. This is a unstable version so 100% Chance your phone will drain battery fast than before!
if you have a solution for that, contact us! juharisunshine@gmail.com

[+] Added new function for run.sh [type:command]
[+] Added detect_package for detecting game target
[+] Focused optimization in system
===================================
1.3@5QP Tester
What's new about this version?
1. added a function that can boost your CPU and GPU
2. makes your game even more smoother than before
3. focusing only game that has been installed, that's will help HQP
boost your game better than before.

[*] NEWLINE [write] > GPU/CPU-PERFORMANCE
[+] Added new function for run.sh [type:command]
[*] Rewrite > [setprop, detect_su]

===================================
1.3QP
[+] Added thermal-throttling
[+] Updated setprop command
[+] Updated file [write:line > 49-50]
[√] fixed [banner] > type:EOF
[+] Added new function for applist.txt [type:package]
[+] Updated file [write:line > 65-74] 


===================================
1.2QP - 1.1QP
[+] Updated file [write:line > 121-300]
[*] Rewrite > [setprop, system limiter, optimizer game, game overlay, throttling, CPU, GPU]
[*] Rewrite > [setprop, detect_su]
[-] Deleted [banner] > type:echo

===================================
1.0
[#] Renamed file [run > run.sh]
[-] Deleted [line: 0] > all

In update 1.5QP soon, I will add a function for deeper optimizing android system, fixing touch problem and others that is secret.
There will be many changes to HQP, we'll see.

Please wait 6 seconds!"
sleep 6.5


if which su > /dev/null 2>&1; then
    status="[+] Root"
else
    status="[x] Non-Root"
fi

cat << "EOF"
   ,:'/¯/`:,       .·/¯/`:,'                 ,.-:^*:*:^:~,      °        ,:´'*:^-:´¯'`:·,         ‘       
  /:/_/::::/';    /:/_/::::';            ,:´:::::::::::::::/_'            '/::::/::::::::::;¯'`*:^:-.,  ‘   
 /:'     '`:/::;  /·´    `·,::';          /::;:-·^*'*'^~-;:/::/`;‘   '     /·´'*^-·´¯'`^·,/::::::::::::'`:,   
 ;         ';:';  ;         ';:;         /:´    ,. –.,_,.'´::/:::';'    ‘  ''`,             ¯'`*^·-:;::::::'\' ‘
 |         'i::i  i         'i:';°     ,/    ,:´';         ;'´¯`,:::'i   °     '`·,                     '`·;:::i'‘
 ';        ;'::/¯/;        ';:;‘'  ' ,'     ';:::`,       ,:     ';::'i            '|       .,_             \:'/' 
 'i        i':/_/:';        ;:';°   ;      ';:::/:`::^*:´;      i::';            'i       'i:::'`·,          i/' ‘
  ;       i·´   '`·;       ;:/°    i       `;/::::::::,·´      ';:/             'i       'i::/:,:          /'   
  ';      ;·,  '  ,·;      ;/'      ';         '` *^*'´         .'/:'`:,           ;      ,'.^*'´     _,.·´‘    
   ';    ';/ '`'*'´  ';    ';/' '‘      '\                        /::::::::`:,‘      ';     ;/ '`*^*'´¯           
    \   /          '\   '/'            `·,                   ´'´¯'`;·;::'/         \    /                      
     '`'´             `''´   '             '`*~·––·~^'´`'\          ';/' ‘         '`^'´‘                      
                      '                                    `·., _,.·'´                                       
EOF

echo ""
sleep 1
echo "Module Execution : $status"
echo "Execution Date : $(date)"
echo""
echo "
<---------------------------------------------------->

DEVICE INFORMATION 

Android Version > $(getprop ro.build.version.release)
Kernel > $(uname -r)
Model > $(getprop ro.product.model)
Hardware >  $(getprop ro.hardware)
Brand > $(getprop ro.product.brand)
Hardware > $(getprop ro.boot.hardware)
Fingerprint > $(getprop ro.vendor.build.fingerprint)
Abi Version > $(getprop ro.product.cpu.abi)
Processor > $(getprop ro.product.board)
Rom > $(getprop ro.build.display.id)

MODULE INFORMATION

Version > ${ver}
Dev > ${dev}
Renderer Type > ${rtyperenderer}
<---------------------------------------------------->
"
echo "
Introducing HQP (High Quality Performance) for Android gaming – the ultimate solution for maximizing your gaming experience. Say goodbye to lags and hello to smooth gameplay."
echo ""

# Automatic file fixer
(
rm /sdcard/HQP/applist.txt/
cp -f /sdcard/HQP/Core/applist.txt /sdcard/HQP/
)> /dev/null 2>&1

sleep 5.5
echo "[ Detecting app! ] "
counter=1
package_list=$(cmd package list packages | cut -f 2 -d ":")  
while IFS= read -r gamelist || [[ -n "$gamelist" ]]; do
opt=$(echo "$gamelist" | awk '!/ /')
    if echo "$package_list" | grep -q "$opt"; then
        echo "$counter. $opt"
        counter=$((counter + 1))
    else
        sed -i "/$opt/d" "$MODPATH/applist.txt"
    fi
done < "$MODPATH/applist.txt"
sleep 2
echo ""
echo "[ Optimization App ]"
sleep 0.5
package_list=$(cmd package list packages | cut -f 2 -d ":")  
while IFS= read -r gamelist || [[ -n "$gamelist" ]]; do
line=$(echo "$gamelist" | awk '!/ /')
    if echo "$package_list" | grep -q "$line"; then
        echo "OPTIMIZING : $line"
        cmd package compile -m speed --check-prof false -f "$line"
        appops set "$line" RUN_IN_BACKGROUND allow
        cmd package compile -m speed --secondary-dex "$line"
        cmd package reconcile-secondary-dex-files "$line"
        cmd game mode performance "$line"
        device_config put game_overlay "$line" mode=2,fps=120
        dumpsys deviceidle whitelist +$opt
        appops set "$line" RUN_IN_BACKGROUND allow
        cmd package compile -m everything-profile -f "$line"
        cmd package compile -r first-boot -f "$line"
        cmd package compile -m speed --check-prof false -f "$line"
        settings put global heads_up_notifications_disabled_package_list "$line"
        cmd sensorservice set-uid-state "$line" activity
        dumpsys power whitelist -c "$line" com.android.server.power.PowerManagerService
        dumpsys deviceidle whitelist -"$line" 
    else
        sed -i "/$line/d" "$MODPATH/applist.txt"
    fi
done < "$MODPATH/applist.txt"
settprops=(
"debug.egl.force_msaa false"
"debug.egl.force_fxaa false"
"debug.egl.force_taa false"
"debug.egl.force_smaa false"
"debug.egl.force_txaa false"
"debug.hwui.disable_scissor_opt false"
"debug.hwui.texture_cache_size 2"
"debug.hwui.layer_cache_size 16"
"debug.hwui.drop_shadow_cache_size 2"
"debug.hwui.skip_empty_damage true"
"debug.hwui.target_cpu_time_percent 45"
"debug.hwui.capture_skp_enabled true"
"debug.hwui.capture_skp_frames 2"
"debug.hwui.use_gpu_pixel_buffers true"
"debug.hwui.level 1"
"debug.hwui.use_buffer_age true"
)
for settprop in "${settprops[@]}"; do
setprop $settprop
done

echo "Applying a new setprop command will take around 0-30 second, please wait "

echo "[ Changing properties ]"
sleep 1.5

setprop debug.performance_schema 1
setprop debug.performance_schema_max_memory_classes 400
setprop debug.performance_schema_max_socket_classes 40
setprop debug.performance.tuning 1
setprop debug.composition.type gpu
setprop debug.MB.inner.running 19
setprop debug.MB.running 45
setprop debug.qsg_renderer 1
setprop debug.enable.gamed 0
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop debug.javafx.animation.fullspeed true
setprop debug.javafx.animation.framerate 120
setprop debug.hwui.target_cpu_time_percent 300
setprop debug.hwui.target_gpu_time_percent 300
setprop debug.hw3d.force true
setprop debug.hw2d.force true
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_msaa false
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_mlaa false
setprop debug.egl.force_txaa false
setprop debug.egl.force_csaa false
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.hwui.fps_divisor -1
setprop debug.redroid.fps 120
setprop debug.disable_sched_boost true
setprop debug.gpu.cooling.callback_freq_limit false
setprop debug.cpu.cooling.callback_freq_limit false
setprop debug.performance.accoustic.force true
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.default-CPU-buffer 65536
setprop debug.hwui.use_hint_manager 1
setprop debug.rs.min-temp_tolerance 99
setprop debug.rs.max-temp_tolerance 100
setprop debug.cpuprio 7
setprop debug.gpuprio 7
setprop debug.ioprio 7
setprop debug.renderer.process compound
setprop debug.gpu.scheduler_pre.emption 1
setprop debug.rs.precision rs_fp_full
setprop debug.disable.hwacc 0
setprop debug.disable.computedata true
setprop debug.gr.swapinterval 0
setprop debug.sf.gpu_freq_index 10
setprop debug.sf.cpu_freq_index 7
setprop debug.sf.mem_freq_index 10
setprop debug.sf.early.app.duration 47200000
setprop debug.sf.early.sf.duration 38300000
setprop debug.sf.earlyGl.app.duration 38350000
setprop debug.sf.earlyGl.sf.duration 29750000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 2925000
setprop debug.sf.high_fps_early_phase_offset_ns 9650000
setprop debug.sf.perf_fps_early_gl_phase_offset_ns 32000000
setprop debug.sf.early_phase_offset_ns 12500000
setprop debug.sf.early_app_phase_offset_ns 12500000
setprop debug.sf.early_gl_phase_offset_ns 750000000
setprop debug.sf.early_gl_app_phase_offset_ns 375000000
setprop debug.sf.high_fps_early_phase_offset_ns 152500000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 20000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 25000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 20000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 15250000
setprop debug.sf.enable_advanced_sf_phase_offset 1
setprop debug.hwui.renderer vulkan
setprop debug.renderthread.vulkan.reduceopstasksplitting true
setprop debug.vk.layers_enabled 1
setprop debug.vk.layers_support 120
setprop debug.vk.swap_buffers 15
setprop debug.power_management_mode pref_max
setprop debug.cpu_managemen_freq freq_max
setprop debug.angle.overlay FPS:Angle*PipelineCache*
setprop debug.renderengine.skiavkthreaded.backend true
setprop debug.renderengine.backend skiavkthreaded
setprop debug.cpu_burst_perf_factor 0.7
setprop debug.cpu_core_ctl_active 1
setprop debug.cpu_core_ctl_busy_down_thres 45
setprop debug.cpu_core_ctl_busy_up_thres 75
setprop debug.cpu_core_ctl_max_cores 8
setprop debug.cpu_core_ctl_offline_delay_ms 456
setprop debug.cpu_efficiency 1.0
setprop debug.performance.tuning.tcp_fin_timeout 30
setprop debug.performance.tuning.cpu 1
setprop debug.performance.profile 1
setprop debug.performance.high 1
setprop debug.sysui.show_app_performance_metrics true
setprop debug.enabletr true
setprop debug.memory.tuning 1
setprop debug.cpu_perf_active true
setprop debug.singlecore.processing 1
setprop debug.multicore.processing 1
setprop debug.egl.gpu_boost true
setprop debug.egl.force_gpu true
setprop debug.hwc.force_gpu 1
setprop debug.hwc.force_cpu 1
setprop debug.sf.max_igbp_list_size 2066200
setprop debug.fb.rgb565 1
setprop debug.min_pointer_dur 4
setprop debug.max.fling_velocity 18000
setprop debug.min.fling_velocity 6000
setprop debug.sf.lag_adj 0
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
settings put secure sysui_tuner_version 5
settings put global job_scheduler_constant null
settings put system pointer_speed 7
settings put global low_power 0
settings put global low_power_sticky 0
settings put system peak_refresh_rate 120.0004
settings put system min_refresh_rate 60.0004
settings put system max_refresh_rate 120.0004
settings put global touch.pressure.scale 0.0001
settings put global view.scroll_friction 10
settings put global touch.size.calibration geometric
settings put global touch.pressure.calibration amplitude
settings put global touch.size.scale 1
settings put global touch.size.bias 0
settings put global touch.size.isSummed 0
settings put global touch.orientation.calibration interpolated
settings put global touch.distance.calibration area
settings put global touch.distance.scale 0
settings put global touch.coverage.calibration box
settings put global touch.gestureMode spots
settings put global MultitouchMinDistancen 1px
settings put global MultitouchSettleInterval 0.1ms
settings put global TapInterval 0.1ms
settings put global TapSlop 1px
settings put global windowsmgr.max_events_per_sec 180
(
setprop debug.sdm.support_writeback 1; setprop debug.sdm.disable_skip_validate 1; setprop debug.sf_frame_rate_multiple_fences 999; setprop debug.sf.early.app.duration 27200000; setprop debug.sf.early.sf.duration 18300000; setprop debug.sf.earlyGl.app.duration 18350000; setprop debug.sf.earlyGl.sf.duration 975000; setprop debug.sf.high_fps_early_gl_phase_offset_ns 925000; setprop debug.sf.high_fps_early_phase_offset_ns 9650000; setprop debug.sf.hw 1; setprop debug.sf.perf_fps_early_gl_phase_offset_ns 12000000; setprop debug.performance_schema 1; setprop debug.performance_schema_max_memory_classes 387; setprop debug.performance_schema_max_socket_classes 10; setprop debug.systemuicompilerfilter speed; setprop debug.sensor.hal 0; setprop debug.sf.max_igbp_list_size 66200; setprop debug.hwui.target_power_time_percent 165; setprop debug.hwui.target_cpu_time_percent 165; setprop debug.hwui.target_gpu_time_percent 165; setprop debug.hwui.target_mem_time_percent 165; setprop debug.disable.hwacc 0; setprop debug.fb.rgb565 1; setprop debug.egl.force_fxaa false; setprop debug.egl.force_taa false; setprop debug.egl.force_msaa false; setprop debug.egl.force_ssaa false; setprop debug.egl.force_smaa false; setprop debug.egl.force_mlaa false; setprop debug.egl.force_txaa false; setprop debug.egl.force_csaa false; setprop debug.enable.gamed 0; setprop debug.gr.swapinterval 0; setprop debug.sf.send_early_power_session_hint false; setprop debug.sf.send_late_power_session_hint false; setprop debug.sf.gpu_freq_index 10; setprop debug.sf.cpu_freq_index 10; setprop debug.sf.mem_freq_index 10; setprop debug.hwui.skip_empty_damage true; setprop debug.enabletr true; setprop debug.hwui.level -1; setprop debug.hwui.fps_divisor -1; setprop debug.hwui.render_compability false; setprop debug.heat_suppression false; setprop debug.kill_allocating_task 45; setprop debug.MB.running 45; setprop debug.MB.inner.running pref_max; setprop debug.power_management_mode false; setprop debug.cpurend.vsync false; setprop debug.gpurend.vsync true; setprop debug.overlayui.enable true; setprop debug.gralloc.disable_ubwc true; setprop debug.stagefright.c2inputsurface true; setprop debug.stagefright.ccodec true; setprop debug.sf.disable_backpressure true; setprop debug.sf.predict_hwc_composition_strategy false; setprop debug.sf.treat_170m_as_sRGB false; setprop debug.display.vds_allow_hwc 1; setprop debug.sf.disable_client_composition_cache 0; setprop debug.performance.cap -1; setprop debug.strncmp.property 4; setprop debug.hwui.use_hint_manager 1; setprop debug.renderer.process 1; setprop debug.threadedOpt 1; setprop debug.choreographer.skipwarning 1; setprop debug.choreographer.callback 60; setprop debug.choreographer.vsync true; setprop debug.frame.pacing 0.1; setprop debug.multicore.processing 120; setprop debug.hwui.disable_draw_defer true; setprop debug.hwui.disable_draw_reorder true; setprop debug.hwui.enable_partial_updates true; setprop debug.atrace.tags.enableflags 134217728; setprop debug.force_rtl false; setprop debug.gralloc.enable_fb_ubwc true; setprop debug.sf.enable_egl_image_tracker true; setprop debug.sf.enable_gl_backpressure true; setprop debug.oculus.refreshRate true; setprop debug.gr.triple_buffer true; setprop debug.hwui.frame_latency true; setprop debug.gralloc.gfx_slot_count true; setprop debug.hwui.triple_buffer true; setprop debug.hwui.disable.double_buffer true; setprop debug.gralloc.map_fb_memory 1; setprop debug.gralloc.enable_fbdev_cache 1; setprop debug.gralloc.gfx_slot_count  120; setprop debug.hwui.tiled_rendering 1; setprop debug.hwui.async_renderer true; setprop debug.hwui.force_async true; setprop debug.hwui.disabledither true; setprop debug.hwui.triple_buffer true; setprop debug.hwui.disable.double_buffer true; setprop debug.hwui.preallocate true; setprop debug.hwui.force_preallocate true; setprop debug.hwui.preallocate_buffers true; setprop debug.hwui.batching true; setprop debug.hwui.optimized_texture_upload true; setprop debug.hwui.enable_mipmap_cache true; setprop debug.hwui.cpu_tuner 1; setprop debug.perf_cpu_time_max_percent 100; setprop debug.perf_cpu_time_min_percent 90;
) 
#Angle Driver ( Gacor kang )
settings put global angle_gl_driver_all_angle 1
settings put global angle_gl_driver_selection_values angle

echo ""
echo "[ Configuring Game Overlay ]"

(
device_config put game_overlay com.ea.gp.apexlegendsmobilefps mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.mobile.legends mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.garena.game.codm mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.dts.freefiremax mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.dts.freefireth mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.miHoYo.GenshinImpact mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.tencent.ig mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.pubg.newstate mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.shooter.modernWarships mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.carxtech.sr mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.pubg.imobile mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.pubg.krmobile mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.HoYoverse.hkrpgoversea mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.roblox.client mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.ngame.allstar.eu mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.garena.game.lmjx mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.miHoYo.bh3global mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.epicgames.fortnite mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.minecraftpe.minecraft.original.free mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.proximabeta.mf.uamo mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay net.wargaming.wot.blitz mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.mobilelegends.hwag mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.ea.gp.fifamobile mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.gameloft.android.ANMP.GloftA8HM mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.igg.android.vikingriseglobal mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.axlebolt.standoff2 mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.kurogame.gplay.punishing.grayraven.en mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.kakaogames.gdts mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay com.netease.newspike mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
device_config put game_overlay jp.konami.pesam mode=2,vulkan=1,downscaleFactor=0.9,fps=120:mode=3,vulkan=0,downscaleFactor=0.9,fps=120
)> /dev/null 2>&1

echo ""
echo "[ Configuring Game Folders ]"
sleep 1.5
(
echo "{
    "configs": [
        {
            "hardwareModel": "$(getprop ro.product.manufacturer) $(getprop ro.product.model)",
            "littleCoreCount": 0,
            "bigCoreCount": 8,
            "littleCoreMask": 255,
            "bigCoreMask": 0,
            "vulkanFlag": 1
        }
    ]
}" > /sdcard/Android/data/com.dts.freefiremax/files/hardware_model_config.json
echo
echo "{
    "configs": [
        {
            "hardwareModel": "$(getprop ro.product.manufacturer) $(getprop ro.product.model)",
            "littleCoreCount": 0,
            "bigCoreCount": 8,
            "littleCoreMask": 255,
            "bigCoreMask": 0,
            "vulkanFlag": 1
        }
    ]
}" > /sdcard/Android/data/com.miHoYo.GenshinImpact/files/hardware_model_config.json
echo
echo "{
    "configs": [
        {
            "hardwareModel": "$(getprop ro.product.manufacturer) $(getprop ro.product.model)",
            "littleCoreCount": 0,
            "bigCoreCount": 8,
            "littleCoreMask": 255,
            "bigCoreMask": 0,
            "vulkanFlag": 1
        }
    ]
}" > /sdcard/Android/data/com.dts.freefireth/files/hardware_model_config.json
echo
echo "{
    "configs": [
        {
            "hardwareModel": "$(getprop ro.product.manufacturer) $(getprop ro.product.model)",
            "littleCoreCount": 0,
            "bigCoreCount": 8,
            "littleCoreMask": 255,
            "bigCoreMask": 0,
            "vulkanFlag": 1
        }
    ]
}" > /sdcard/Android/data/com.garena.game.codm/files/hardware_model_config.json
echo
echo "{
    "configs": [
        {
            "hardwareModel": "$(getprop ro.product.manufacturer) $(getprop ro.product.model)",
            "littleCoreCount": 0,
            "bigCoreCount": 8,
            "littleCoreMask": 255,
            "bigCoreMask": 0,
            "vulkanFlag": 1
        }
    ]
}" > /sdcard/Android/data/com.mobile.legends/files/hardware_model_config.json
)> /dev/null 2>&1
(
cmd looper_stats disable
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
cmd power set-mode 0
cmd thermalservice override-status 0
)> /dev/null 2>&1

echo ""
echo "[ Optimizing Game Only ]"
(
cmd package compile -m speed -f com.ea.gp.apexlegendsmobilefps
cmd package compile -m speed -f com.mobile.legends
cmd package compile -m speed -f com.garena.game.codm
cmd package compile -m speed -f com.dts.freefiremax
cmd package compile -m speed -f com.dts.freefireth
cmd package compile -m speed -f com.miHoYo.GenshinImpact
cmd package compile -m speed -f com.tencent.ig
cmd package compile -m speed -f com.pubg.newstate
cmd package compile -m speed -f com.shooter.modernWarships
cmd package compile -m speed -f com.carxtech.sr
cmd package compile -m speed -f com.pubg.imobile
cmd package compile -m speed -f com.pubg.krmobile
cmd package compile -m speed -f com.HoYoverse.hkrpgoversea
cmd package compile -m speed -f com.roblox.client
cmd package compile -m speed -f com.ngame.allstar.eu
cmd package compile -m speed -f com.garena.game.lmjx
cmd package compile -m speed -f com.miHoYo.bh3global
cmd package compile -m speed -f com.epicgames.fortnite
cmd package compile -m speed -f com.minecraftpe.minecraft.original.free
cmd package compile -m speed -f com.proximabeta.mf.uamo
cmd package compile -m speed -f net.wargaming.wot.blitz
cmd package compile -m speed -f com.mobilelegends.hwag
cmd package compile -m speed -f com.ea.gp.fifamobile
cmd package compile -m speed -f com.gameloft.android.ANMP.GloftA8HM
cmd package compile -m speed -f com.igg.android.vikingriseglobal
cmd package compile -m speed -f com.axlebolt.standoff2
cmd package compile -m speed -f com.kurogame.gplay.punishing.grayraven.en
cmd package compile -m speed -f com.kakaogames.gdts
cmd package compile -m speed -f com.netease.newspike
cmd package compile -m speed -f jp.konami.pesam
)> /dev/null 2>&1
(
cmd game mode performance com.ea.gp.apexlegendsmobilefps
cmd game mode performance com.mobile.legends
cmd game mode performance com.garena.game.codm
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.dts.freefireth
cmd game mode performance com.miHoYo.GenshinImpact
cmd game mode performance com.tencent.ig
cmd game mode performance com.pubg.newstate
cmd game mode performance com.shooter.modernWarships
cmd game mode performance com.carxtech.sr
cmd game mode performance com.pubg.imobile
cmd game mode performance com.pubg.krmobile
cmd game mode performance com.HoYoverse.hkrpgoversea
cmd game mode performance com.roblox.client
cmd game mode performance com.ngame.allstar.eu
cmd game mode performance com.garena.game.lmjx
cmd game mode performance com.miHoYo.bh3global
cmd game mode performance com.epicgames.fortnite
cmd game mode performance com.minecraftpe.minecraft.original.free
cmd game mode performance com.proximabeta.mf.uamo
cmd game mode performance net.wargaming.wot.blitz
cmd game mode performance com.mobilelegends.hwag
cmd game mode performance com.ea.gp.fifamobile
cmd game mode performance com.gameloft.android.ANMP.GloftA8HM
cmd game mode performance com.igg.android.vikingriseglobal
cmd game mode performance com.axlebolt.standoff2
cmd game mode performance com.kurogame.gplay.punishing.grayraven.en
cmd game mode performance com.kakaogames.gdts
cmd game mode performance com.netease.newspike
cmd game mode performance jp.konami.pesam
)> /dev/null 2>&1
(
cmd stats clear-puller-cache
mv /sdcard/HQP/Core/vulkan /data/local/tmp && chmod +x /data/local/tmp/vulkan && /data/local/tmp/vulkan
)> dev/null 2>&1

echo ""
echo "[ Tweaking CPU & GPU ]"
(
coresmax=$(cat /android/data/com.android.system.init.d/cpu/kernel_max) 2>/dev/null
if [ -z ${cores} ]; then
    cores=$(( ${coresmax} + 1 ))
fi

CPU_BOOST="/android/devices/cpu_mode_Peformamce"
GPU_BOOST="/android/devices/gpu_mode_Performance"

# GPU BOOST TWEAKS
_get_maxfreq() {
    local fpath="/android/data/system/cpu/cpu$1/cpufreq/scaling_available_frequencies"
    local maxfreq="0"

    if [ ! -f "$fpath" ]; then
        echo ""
        return
    fi

    for f in $(cat $fpath); do
        [ "$f" -gt "$maxfreq" ] && maxfreq="$f"
    done
    echo "$maxfreq"
}

GPU_MIN="$(min $GPU_FREQS)"
GPU_MAX="$(max $GPU_FREQS)"
    
if [ ! -e ${GPU_FREQS} ]; then
    GPU_MIN=$(cat "$GPU_DIR/devfreq/min_freq") 2>/dev/null  
    GPU_MAX=$(cat "$GPU_DIR/devfreq/max_freq") 2>/dev/null  
fi

if [ ! -e ${GPU_DIR}/devfreq/max_freq ] && [ ! -e ${GPU_DIR}/devfreq/max_freq ]; then
    GPU_MIN=$(cat "$GPU_DIR/gpuclk") 2>/dev/null  
    GPU_MAX=$(cat "$GPU_DIR/max_gpuclk") 2>/dev/null  
fi

if [ ${PROFILE} -eq 0 ]; then
    PROFILE_M="performance"
elif [ ${PROFILE} -eq 1 ]; then
    PROFILE_M="performance"
elif [ ${PROFILE} -eq 2 ]; then
    PROFILE_M="performance"
fi

coresbig=$(( ${cores} / 2 ))

maxfreq="$(_get_maxfreq $coresbig)"
maxfreq=$(awk -v x=$maxfreq 'BEGIN{print x/1000000}')
maxfreq=$(round ${maxfreq} 2)

GPU_MAX_MHz=$(awk -v x=$GPU_MAX 'BEGIN{print x/1000000}')
GPU_MAX_MHz=$(round ${GPU_MAX_MHz} 0)

# CPU BOOST TWEAKS
_get_maxfreq() {
    local fpath="/android/data/system/cpu/cpu$1/cpufreq/scaling_available_frequencies"
    local maxfreq="0"

    if [ ! -f "$fpath" ]; then
        echo ""
        return
    fi

    for f in $(cat $fpath); do
        [ "$f" -gt "$maxfreq" ] && maxfreq="$f"
    done
    echo "$maxfreq"
}

CPU_MIN="$(min $CPU_FREQS)"
CPU_MAX="$(max $CPU_FREQS)"
    
if [ ! -e ${CPU_FREQS} ]; then
    CPU_MIN=$(cat "$CPU_DIR/devfreq/min_freq") 2>/dev/null  
    CPU_MAX=$(cat "$CPU_DIR/devfreq/max_freq") 2>/dev/null  
fi

if [ ! -e ${GPU_DIR}/devfreq/max_freq ] && [ ! -e ${GPU_DIR}/devfreq/max_freq ]; then
    CPU_MIN=$(cat "$CPU_DIR/gpuclk") 2>/dev/null  
    CPU_MAX=$(cat "$CPU_DIR/max_gpuclk") 2>/dev/null  
fi

if [ ${PROFILE} -eq 0 ]; then
    PROFILE_M="performance"
elif [ ${PROFILE} -eq 1 ]; then
    PROFILE_M="performance"
elif [ ${PROFILE} -eq 2 ]; then
    PROFILE_M="performance"
fi

coresbig=$(( ${cores} / 2 ))

maxfreq="$(_get_maxfreq $coresbig)"
maxfreq=$(awk -v x=$maxfreq 'BEGIN{print x/1000000}')
maxfreq=$(round ${maxfreq} 2)

CPU_MAX_MHz=$(awk -v x=$GPU_MAX 'BEGIN{print x/1000000}')
CPU_MAX_MHz=$(round ${GPU_MAX_MHz} 0)
)> dev/null 2>&1
echo ""
echo "[ Disabling System Limiter ]"

function reset_throttling () {
 cmd shortcut reset-throttling
 cmd shortcut reset-all-throttling
}

cmd thermalservice override-status 0
cmd shortcut reset-throttling > dev/null 2>&1
cmd shortcut reset-all-throttling > dev/null 2>&1

(
for idle in $(dumpsys deviceidle whitelist | cut -f 2 -d ,); do
dumpsys deviceidle whitelist -$idle
done
for system in $(cmd package list packages -s | cut -f 2 -d :); do
cmd appops set $system RUN_IN_BACKGROUND ignore
done
for third in $(cmd package list packages -3 | cut -f 2 -d :); do
cmd appops set $third RUN_IN_BACKGROUND allow
dumpsys deviceidle whitelist +$third
done
)> /dev/null 2>&1

UI=Reloaded
echo "Reloading [UI]..." 
am start -a android.intent.action.VIEW -d ${support} > /dev/null 2>&1
am broadcast -a android.intent.action.MAIN -c android.intent.category.HOME > dev/null 2>&1
echo "UI Status : ${UI}"
echo ""
echo "[ Network Optimization ]"
setprop debug.network.type full
sleep 1.5
echo ""
echo "[ Optimizing System DEVICE=$(getprop ro.product.brand) ]"
(
settings put secure sysui_tuner_version 5
settings put global job_scheduler_constant 1
settings put system pointer_speed 7
settings put global low_power 0
settings put global low_power_sticky 0
settings put global cpu0_max_pwr 2
settings put global cpu1_max_pwr 2
settings put global cpu2_max_pwr 2
settings put global cpu3_max_pwr 2
settings put global cpu4_max_pwr 2
settings put global cpu5_max_pwr 2
settings put global cpu6_max_pwr 2
settings put global cpu7_max_pwr 2
setprop debug.hwui.use_hint_manager 1
setprop debug.performance.use_hint_manager 1
cmd power set-fixed-performance-mode-enabled true
setprop debug.qctwa.statusbar 0
)> dev/null 2>&1
echo ""
echo "Testing device [0/5] < Gathering information >"

# Supaya lebih keren aja kelihatan nya, wkwkwk
(
dumpsys thermalservice
sleep 1.5
cat /sys/class/thermal/thermal_zone0/temp
sleep 1.5
top -n 1
sleep 1.5
cat /proc/cpuinfo
sleep 1.5
dumpsys SurfaceFlinger --latency-clear
)> dev/null 2>&1
echo "[1/5] TESTED [Status=NORMAL]"
sleep 2.5
echo "[2/5] TESTED [Status=NORMAL]"
sleep 2.5
echo "[3/5] TESTED [Status=NORMAL]"
sleep 2.5
echo "[4/5] TESTED [Status=NORMAL]"
sleep 2.5
echo "[5/5] TESTED [Status=NORMAL]"
echo ""
echo "DEVICE=$(getprop ro.product.brand) [VERSION= $(getprop ro.build.version.release)]" All normal without an error
echo ""
#AxeronCore/Adaptor
axeron_core=$(cat <<-EOF
Optione {
key:title="AxeronCore X HQP";
key:dev="HighQuality Performance";
key:desc="Introducing HQP the ultimate solution for maximizing your gaming experience fixing all problem including lag and fps problem, HQP make your games more smoother";
key:parentApp="$1";
}
EOF
)
cmd notification post -S bigtext -t 'High Quality Performance' 'Installation in Progress' "Successful installation [HQP]" > /dev/null 2>&1 &

target_app_axeron=$(echo "$1" | awk '{print $NF}')
echo "_________________________________"
echo "AxeronCore status > [Installing]"
echo "Target game > [${target_app_axeron}]"
echo ""
echo "Please Wait..."
path="/storage/emulated/0/HQP"

sh ${path}/Core/AxeronCore "$axeron_core"  "$path" "$1"
